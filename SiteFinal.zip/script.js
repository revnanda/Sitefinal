function mostrar (secaoid) {
    const secoes = document.querySelectorAll("section");
    secoes.forEach(secao => secao.classList.remove("active"))
    document.getElementById(secaoid).classList.add("active")
}


document.addEventListener("DOMContentLoaded", function () {
    const video = document.getElementById("introVideo");
    video.play().catch(error => {
        console.log("Autoplay bloqueado, tentando novamente...");
        video.muted = true;
        video.play();
    });
    video.addEventListener("ended", function () {
        video.classList.add("fade-out");
        setTimeout(() => {
            window.location.href = "Fichas_RPG_CPII.html";
        }, 1000);
    });
});





